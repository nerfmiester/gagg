# gagg
Command line agg
